/**
 * Inventory class with static methods to manage the Part and Product lists.
 */

/**
 *
 * @author Joshua Vinson
 */
package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Inventory {

    // Declare fields
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();
    private static int uniquePartId = 0;
    private static int uniqueProductId = 999;

    // Declare methods
    /**
     * Increases the uniquePartId variable by 1 and returns a new unique value.
     * @return a unique Part ID
     */
    public static int getUniquePartId() {
        uniquePartId++;
        return uniquePartId;
    }

    /**
     * Increases the uniqueProductId variable by 1 and returns a new unique value.
     * @return a unique Product ID
     */
    public static int getUniqueProductId() {
        uniqueProductId++;
        return uniqueProductId;
    }

    /**
     * @param newPart Adds a new Part to the end of the allParts list.
     */
    public static void addPart (Part newPart){
        allParts.add(newPart);
    }

    /**
     * @param newProduct Adds a new Product to the end of the allProducts list.
     */
    public static void addProduct (Product newProduct){
        allProducts.add(newProduct);
    }

    public static Part lookupPart(int partId){

        return null;
    }

    public static Product lookupProduct(int productId){
        return null;
    }

    /**
     * Searches the allParts list for the users input.
     * Create a copy of the allParts list and sets it toLowerCase.
     * The list is checked in its original form and lower case form, to check for case sensitivity.
     * If a match is found, it's added to a list to be returned for display.
     * @param partName the user input to search for
     * @return the matched search term(s)
     */
    public static ObservableList<Part> lookupPart (String partName){
        ObservableList<Part> namedParts = FXCollections.observableArrayList();
        ObservableList<Part> allNamedParts = Inventory.getAllParts();

        for (Part np : allNamedParts){
            String lowernp = np.getName().toLowerCase();
            int id = np.getId();
            String sid = Integer.toString(id);

            if(lowernp.contains(partName) || np.getName().contains(partName) || sid.contains(partName)) {
                namedParts.add(np);
            }
        }
        return namedParts;
    }

    /**
     * Searches the allParts list for the users input.
     * Create a copy of the allParts list and sets it toLowerCase.
     * The list is checked in its original form and lower case form, to check for case sensitivity.
     * If a match is found, it's added to a list to be returned for display.
     * @param productName the user input to search for
     * @return the matched search term(s)
     */
    public static ObservableList<Product> lookupProduct(String productName){
        ObservableList<Product> namedProducts = FXCollections.observableArrayList();
        ObservableList<Product> allNamedProducts = Inventory.getAllProducts();

        for (Product np : allNamedProducts) {
            String lowernp = np.getName().toLowerCase();
            int id = np.getId();
            String sid = Integer.toString(id);

            if (lowernp.contains(productName) || np.getName().contains(productName) || sid.contains(productName)) {
                namedProducts.add(np);
            }
        }
        return namedProducts;
    }

    /**
     * Used to update an entry in the allParts list.
     * @param index the index to update
     * @param selectedPart the Part data to update
     */
    public static void updatePart (int index, Part selectedPart){
        allParts.set(index, selectedPart);
    }

    /**
     * Used to update an entry in the allProducts list.
     * @param index the index to update
     * @param newProduct the Product data to update
     */
    public static void updateProduct (int index, Product newProduct){
        allProducts.get(index).setId(newProduct.getId());
        allProducts.get(index).setName(newProduct.getName());
        allProducts.get(index).setStock(newProduct.getStock());
        allProducts.get(index).setPrice(newProduct.getPrice());
        allProducts.get(index).setMax(newProduct.getMax());
        allProducts.get(index).setMin(newProduct.getMin());
    }

    public static boolean deletePart(Part selectedPart){
        return true;
    }

    public static boolean deleteProduct(Product selectedProduct){
        return true;
    }

    /**
     * @return the allParts observable array list
     */
    public static ObservableList<Part> getAllParts() {
        return allParts;
    }

    /**
     * @return the allProducts observable array list
     */
    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }
}
