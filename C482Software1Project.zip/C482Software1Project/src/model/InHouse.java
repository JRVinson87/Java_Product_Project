/**
 * This class sets up the InHouse subclass of the Parts class.
 */

/**
 *
 * @author Joshua Vinson
 */
package model;

public class InHouse extends Part{

    // Declare fields
    private int machineId;

    /**
     * Sets up the constructor for create an instance of an InHouse Part.
     * @param id the id to set
     * @param name the name to set
     * @param price the price to set
     * @param stock the stock to set
     * @param min the min to set
     * @param max the max to set
     * @param machineId the machineId to set
     */
    public InHouse(int id, String name, double price, int stock, int min, int max, int machineId) {
        super(id, name, price, stock, min, max);
        this.machineId = machineId;
    }

    // Declare methods
    /**
     * @return the machine ID
     */
    public int getMachineId() {
        return machineId;
    }

    /**
     * @param machineId the machine ID to set
     */
    public void setMachineId(int machineId) {
        this.machineId = machineId;
    }
}
