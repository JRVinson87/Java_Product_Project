/**
 * Sets up the Outsourced subclass of the Part class.
 */

/**
 *
 * @author Joshua Vinson
 */
package model;

public class Outsourced extends Part{

    // Declare fields
    private String companyName;

    /**
     * Sets up a constructor for an Outsourced object.
     * @param id the id to set
     * @param name the name to set
     * @param price the price to set
     * @param stock the stock to set
     * @param min the min to set
     * @param max the max to set
     * @param companyName the company name to set
     */
    public Outsourced(int id, String name, double price, int stock, int min, int max, String companyName) {
        super(id, name, price, stock, min, max);
        this.companyName = companyName;
    }

    // Declare methods
    /**
     * @return the company name
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * @param companyName the company name to set
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}
