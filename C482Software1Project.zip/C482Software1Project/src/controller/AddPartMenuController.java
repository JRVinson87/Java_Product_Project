/**
 * This houses the methods for the Add Part view controller.
 */

/**
 *
 * @author Joshua Vinson
 */
package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class AddPartMenuController implements Initializable {

    // stage and scene instance
    Stage stage;
    Parent scene;

    // @FXML annotation to ensure the declarations match FXIDs
    @FXML
    private Label labelAddPartMachineID;

    // @FXML Toggle Group for radio buttons
    @FXML
    private ToggleGroup sourceTG;

    @FXML
    private RadioButton radioAddPartInHouse;

    @FXML
    private RadioButton radioAddPartOutsourced;

    @FXML
    private TextField textfieldAddPartID;

    @FXML
    private TextField textfieldAddPartInv;

    @FXML
    private TextField textfieldAddPartMachineID;

    @FXML
    private TextField textfieldAddPartMax;

    @FXML
    private TextField textfieldAddPartMin;

    @FXML
    private TextField textfieldAddPartName;

    @FXML
    private TextField textfieldAddPartPrice;

    // @FXML button actions

    /**
     * Returns to the main menu.
     * @param event Cancel button is clicked.
     * @throws IOException
     */
    @FXML
    void onActionDisplayMain(ActionEvent event) throws IOException {
        // casting the getsource to Button object and the whole statement to Stage object
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        // loading the fxml doc to reference
        scene = FXMLLoader.load(getClass().getResource("/view/MainMenu.fxml"));
        // add the scene to the stage
        stage.setScene(new Scene(scene));
        // show the stage
        stage.show();
    }

    /**
     * Adds a new Part.
     * The ID for the part will be created with the getUniquePartId method.
     * Text input for name, stock, price, max inv, and min inv are taken for the addPart parameter.
     * Max is checked to be greater than min and current stock is checked to be between min and max inventory levels.
     * User input is checked to be the correct data type. If invalid entries are found, a warning will alert the user and return.
     * A check is made for which radio button is selected so that the final text field can be assigned correctly.
     * If entry is valid, the addPart method will be called to update the Part.
     * @param event
     * @throws IOException
     */
    @FXML
    void onActionSave(ActionEvent event) throws IOException {

        try {
            int machineId;
            String companyName;

            int id = Inventory.getUniquePartId();
            String name = textfieldAddPartName.getText();
            int stock = Integer.parseInt(textfieldAddPartInv.getText());
            double price = Double.parseDouble(textfieldAddPartPrice.getText());
            int max = Integer.parseInt(textfieldAddPartMax.getText());
            int min = Integer.parseInt(textfieldAddPartMin.getText());

            if (max < min){
                Alert alert1 = new Alert(Alert.AlertType.ERROR);
                alert1.setTitle("Error Dialog");
                alert1.setContentText("Invalid value(s) entered. Min must be less than or equal to Max");
                alert1.showAndWait();
                return;
            }
            if (stock < min || stock > max){
                Alert alert2 = new Alert(Alert.AlertType.ERROR);
                alert2.setTitle("Error Dialog");
                alert2.setContentText("Invalid value(s) entered. Inv must be between, or match, Min and Max ");
                alert2.showAndWait();
                return;
            }

            if (radioAddPartInHouse.isSelected()) {
                machineId = Integer.parseInt(textfieldAddPartMachineID.getText());
                Inventory.addPart(new InHouse(id, name, price, stock, min, max, machineId));
            } else {
                companyName = textfieldAddPartMachineID.getText();
                Inventory.addPart(new Outsourced(id, name, price, stock, min, max, companyName));
            }

            // casting the getsource to Button object and the whole statement to Stage object
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            // loading the fxml doc to reference
            scene = FXMLLoader.load(getClass().getResource("/view/MainMenu.fxml"));
            // add the scene to the stage
            stage.setScene(new Scene(scene));
            // show the stage
            stage.show();
        }
        catch(NumberFormatException e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Invalid value(s) entered. Please try again.\n" + e.getLocalizedMessage());
            alert.showAndWait();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    /**
     * Changes the machineId label to Machine ID when the InHouse radio button is clicked.
     * @param actionEvent InHouse radio button selected.
     */
    public void onActionInHouse(ActionEvent actionEvent) {
        labelAddPartMachineID.setText("Machine ID");
        textfieldAddPartMachineID.setPromptText("Machine ID");
    }

    /**
     * Changes the machineId label to Company Name when the Outsourced radio button is clicked.
     * @param actionEvent Outsourced radio button clicked.
     */
    public void onActionOutsourced(ActionEvent actionEvent) {
        labelAddPartMachineID.setText("Company Name");
        textfieldAddPartMachineID.setPromptText("Company Name");
    }
}
