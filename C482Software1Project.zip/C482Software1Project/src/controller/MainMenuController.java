/**
 * This houses the methods for the Main Menu controller.
 */

/**
 *
 * @author Joshua Vinson
 */
package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import model.Inventory;
import model.Part;
import model.Product;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLOutput;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;

public class MainMenuController implements Initializable {

    // initialize stage and scene
    Stage stage;
    Parent scene;

    // @FXML annotation to ensure the declarations match FXIDs
    @FXML
    private TableView<Part> tableMainPart;
    @FXML
    private TableView<Product> tableMainProd;
    @FXML
    private TableColumn<Part, Integer> tablecolMainPartInv;
    @FXML
    private TableColumn<Part, Integer> tablecolMainPartPartID;
    @FXML
    private TableColumn<Part, String> tablecolMainPartPartName;
    @FXML
    private TableColumn<Part, Double> tablecolMainPartPrice;
    @FXML
    private TableColumn<Product, Integer> tablecolMainProdProdID;
    @FXML
    private TableColumn<Product, Integer> tablecolMainProdProdInv;
    @FXML
    private TableColumn<Product, String> tablecolMainProdProdName;
    @FXML
    private TableColumn<Product, Double> tablecolMainProdProdPrice;
    @FXML
    private TextField textfieldMainPart;
    @FXML
    private TextField textfieldMainProd;

    // @FXML for button actions
    @FXML
    void onActionAddPart(ActionEvent event) throws IOException {
        // casting the getsource to Button object and the whole statement to Stage object
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        // loading the fxml doc to reference
        scene = FXMLLoader.load(getClass().getResource("/view/AddPartMenu.fxml"));
        // add the scene to the stage
        stage.setScene(new Scene(scene));
        // show the stage
        stage.show();
    }

    @FXML
    void onActionAddProd(ActionEvent event) throws IOException {
        // casting the getsource to Button object and the whole statement to Stage object
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        // loading the fxml doc to reference
        scene = FXMLLoader.load(getClass().getResource("/view/AddProductMenu.fxml"));
        // add the scene to the stage
        stage.setScene(new Scene(scene));
        // show the stage
        stage.show();
    }

    /**
     * Displays a confirmation box and removes selected Part when user selects OK.
     * Dialog box asks the user if they want to remove the selected Part from the allParts list and table.
     * If no Part is selected or the user does not click OK, it returns.
     * The getAllParts.remove method is called with the Part via an assigned temporary variable.
     * @param event Remove button pressed
     */
    @FXML
    void onActionDeletePart(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Remove");
        alert.setContentText("This will remove the selected part from the inventory.\n" + "Do you want to remove?");
        Optional<ButtonType> result = alert.showAndWait();

        if(result.isPresent() && result.get() == ButtonType.OK){
            Part sp = tableMainPart.getSelectionModel().getSelectedItem();

            if (sp == null) {
                return;
            }

            Inventory.getAllParts().remove(sp);
        }
        return;
    }

    /**
     * Displays a confirmation box and removes selected Product when user selects OK.
     * First the product is checked to see if it has any associated parts.
     * If it does, a dialog box warns the user that they cannot remove the Product until the associated Parts are removed.
     * Dialog box asks the user if they want to remove the selected Product from the allProducts list and table.
     * If no Product is selected or the user does not click OK, it returns.
     * The getAllProducts.remove method is called with the Product via an assigned temporary variable.
     * @param event Remove button pressed
     */
    @FXML
    void onActionDeleteProd(ActionEvent event) {

        Product sp = tableMainProd.getSelectionModel().getSelectedItem();
        if(!sp.getAllAssociatedParts().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning");
            alert.setContentText("This product has an associated parts list.\n"
                    + "Please remove the associated parts before removing the product.");
            alert.showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Remove");
        alert.setContentText("This will remove the selected product from the inventory.\n" + "Do you want to remove?");
        Optional<ButtonType> result = alert.showAndWait();

        if(result.isPresent() && result.get() == ButtonType.OK){
            if (sp == null) {
                return;
            }
            Inventory.getAllProducts().remove(sp);
        }
        return;
    }

    /**
     * Exits the application.
     * @param event Exit button is pressed.
     */
    @FXML
    void onActionExitMain(ActionEvent event) {
        // shutdown app, pass in 0 to exit
        System.exit(0);
    }

    /**
     * Passes the users table selection to the new view and controller.
     * FXML loader object is made to call the setSelection method in order to pass Part data to the next view.
     * @param event User selects an table entry and presses the Modify button.
     * @throws IOException
     */
    @FXML
    void onActionModPart(ActionEvent event) throws IOException {

        if (tableMainPart.getSelectionModel().getSelectedItem() != null) {

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/ModPartMenu.fxml"));
            loader.load();

            ModPartMenuController ModPartController = loader.getController();
            ModPartController.setSelection(tableMainPart.getSelectionModel().getSelectedItem());

            // casting the getsource to Button object and the whole statement to Stage object
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            // reference to table
            Parent scene = loader.getRoot();
            // add the scene to the stage
            stage.setScene(new Scene(scene));
            // show the stage
            stage.show();
        } else
            return;
    }

    /**
     * Passes the users table selection to the new view and controller.
     * FXML loader object is made to call the setSelection method in order to pass Product data to the next view.
     * @param event User selects an table entry and presses the Modify button.
     */
    @FXML
    void onActionModProd(ActionEvent event) throws IOException {

        if (tableMainProd.getSelectionModel().getSelectedItem() != null) {

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/ModProductMenu.fxml"));
            loader.load();

            ModProductMenuController ModProdController = loader.getController();
            ModProdController.setSelection(tableMainProd.getSelectionModel().getSelectedItem());

            // casting the getsource to Button object and the whole statement to Stage object
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            // reference to table
            Parent scene = loader.getRoot();
            // add the scene to the stage
            stage.setScene(new Scene(scene));
            // show the stage
            stage.show();
        } else
            return;
    }

    /**
     * Searches allParts list for user input while the user types.
     * Stores user input in a temporary String and stores Part matches in a temporary list.
     * Returns the list of matches.
     */
    public void onKeySearchPart(KeyEvent keyEvent) {
        String queryPart = textfieldMainPart.getText();

        ObservableList<Part> parts = Inventory.lookupPart(queryPart);

        tableMainPart.setItems(parts);
    }

    /**
     * Searches allProducts list for user input while the user types.
     * Stores user input in a temporary String and stores Product matches in a temporary list.
     * Returns the list of matches.
     */
    public void onKeySearchProduct(KeyEvent keyEvent) {
        String queryPart = textfieldMainProd.getText();

        ObservableList<Product> prod = Inventory.lookupProduct(queryPart);

        tableMainProd.setItems(prod);
    }

    /**
     * Initialize is called with the view loads and populates the tables cell values.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        tableMainPart.setItems(Inventory.getAllParts());
        tablecolMainPartPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        tablecolMainPartPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        tablecolMainPartInv.setCellValueFactory(new PropertyValueFactory<>("stock"));
        tablecolMainPartPrice.setCellValueFactory(new PropertyValueFactory<>("price"));

        tableMainProd.setItems(Inventory.getAllProducts());
        tablecolMainProdProdID.setCellValueFactory(new PropertyValueFactory<>("id"));
        tablecolMainProdProdName.setCellValueFactory(new PropertyValueFactory<>("name"));
        tablecolMainProdProdInv.setCellValueFactory(new PropertyValueFactory<>("stock"));
        tablecolMainProdProdPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
    }
}