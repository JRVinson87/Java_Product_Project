/**
 * This houses the methods for the Modify Product view controller.
 */

/**
 *
 * @author Joshua Vinson
 */package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class ModProductMenuController implements Initializable {

    // stage and scene instance
    Stage stage;
    Parent scene;

    //holds index
    int ind;

    //holds ID of selected part
    private int passID;

    //holds selected part for removal
    private Product oldProduct;

    // @FXML annotation to ensure the declarations match FXIDs

    @FXML
    private TableView<Part> tableModProdAssociatedPart;

    @FXML
    private TableView<Part> tableModProdAvailPart;

    @FXML
    private TableColumn<Part, Integer> tablecolModProdAssocPartID;

    @FXML
    private TableColumn<Part, Integer> tablecolModProdAssocPartInv;

    @FXML
    private TableColumn<Part, String> tablecolModProdAssocPartName;

    @FXML
    private TableColumn<Part, Double> tablecolModProdAssocPartPrice;

    @FXML
    private TableColumn<Part, Integer> tablecolModProdAvailPartID;

    @FXML
    private TableColumn<Part, Integer> tablecolModProdAvailPartInv;

    @FXML
    private TableColumn<Part, String> tablecolModProdAvailPartName;

    @FXML
    private TableColumn<Part, Double> tablecolModProdAvailPartPrice;

    @FXML
    private TextField textfieldModProdID;

    @FXML
    private TextField textfieldModProdInv;

    @FXML
    private TextField textfieldModProdMax;

    @FXML
    private TextField textfieldModProdMin;

    @FXML
    private TextField textfieldModProdName;

    @FXML
    private TextField textfieldModProdPrice;

    @FXML
    private TextField textfieldModProdSearch;

    /**
     * Searches allParts list for user input while the user types.
     * Stores user input in a temporary String and stores Part matches in a temporary list.
     * Returns the list of matches.
     */
    public void onKeySearchPart(KeyEvent keyEvent) {
        String queryPart = textfieldModProdSearch.getText();

        ObservableList<Part> parts = Inventory.lookupPart(queryPart);

        tableModProdAvailPart.setItems(parts);
    }

    /**
     * Adds the users current selection to the associatedParts list and the associated parts table.
     * Puts the users selection into a temp Part. If nothing is selected, it just returns.
     * The addAssociatedParts method takes in the selected Part and the setItems displays the part on the associated table.
     * @param event Add button press
     */
    @FXML
    void onActionAddPart(ActionEvent event) {

        Part sp = tableModProdAvailPart.getSelectionModel().getSelectedItem();

        if (sp == null)
            return;

        // add to associated list
        oldProduct.addAssociatedPart(sp);
        tableModProdAssociatedPart.setItems(oldProduct.getAllAssociatedParts());

    }

    /**
     * Displays a confirmation box and removes selected Part when user selects OK.
     * Dialog box asks the user if they want to remove the selected Part from the associatedParts list and table.
     * If no Part is selected or the user does not click OK, it returns.
     * The deleteAssociatedPart method is called with the Part via an assigned temporary variable.
     * @param event Remove button pressed
     */
    @FXML
    void onActionRemovePart(ActionEvent event) {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Remove");
        alert.setContentText("This will remove the selected part from the associated parts list.\n" + "Do you want to remove?");
        Optional<ButtonType> result = alert.showAndWait();

        if(result.isPresent() && result.get() == ButtonType.OK){
            Part sp = tableModProdAssociatedPart.getSelectionModel().getSelectedItem();

            if (sp == null) {
                return;
            }

            oldProduct.deleteAssociatedPart(sp);
        }
        return;
    }

    /**
     * Returns to the main menu.
     * @param event Cancel button is clicked.
     * @throws IOException
     */
    @FXML
    void onActionDisplayMain(ActionEvent event) throws IOException {
        // casting the getsource to Button object and the whole statement to Stage object
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        // loading the fxml doc to reference
        scene = FXMLLoader.load(getClass().getResource("/view/MainMenu.fxml"));
        // add the scene to the stage
        stage.setScene(new Scene(scene));
        // show the stage
        stage.show();
    }

    /**
     * Saves the modifications to the selected Product.
     * The ID for the product will be copied from the selected Product so that it stays the same.
     * Text input for name, stock, price, max inv, and min inv are taken and assigned to a local Product instance.
     * Max is checked to be greater than min and current stock is checked to be between min and max inventory levels.
     * User input is checked to be the correct data type. If invalid entries are found, a warning will alert the user and return.
     * If entry is valid, the updateProduct method will be called to update the Product.
     * @param event
     * @throws IOException
     */
    @FXML
    void onActionSave(ActionEvent event) throws IOException {

        try {
            int id = passID;
            String name = textfieldModProdName.getText();
            int stock = Integer.parseInt(textfieldModProdInv.getText());
            double price = Double.parseDouble(textfieldModProdPrice.getText());
            int max = Integer.parseInt(textfieldModProdMax.getText());
            int min = Integer.parseInt(textfieldModProdMin.getText());

            if (max < min){
                Alert alert1 = new Alert(Alert.AlertType.ERROR);
                alert1.setTitle("Error Dialog");
                alert1.setContentText("Invalid value(s) entered. Min must be less than or equal to Max");
                alert1.showAndWait();
                return;
            }
            if (stock < min || stock > max){
                Alert alert2 = new Alert(Alert.AlertType.ERROR);
                alert2.setTitle("Error Dialog");
                alert2.setContentText("Invalid value(s) entered. Inv must be between, or match, Min and Max ");
                alert2.showAndWait();
                return;
            }

            Product tempProd = new Product(id, name, price, stock, min, max);
            Inventory.updateProduct(ind, tempProd);

            // casting the getsource to Button object and the whole statement to Stage object
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            // loading the fxml doc to reference
            scene = FXMLLoader.load(getClass().getResource("/view/MainMenu.fxml"));
            // add the scene to the stage
            stage.setScene(new Scene(scene));
            // show the stage
            stage.show();
        }
        catch(NumberFormatException e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Invalid value(s) entered. Please try again.\n" + e.getLocalizedMessage());
            alert.showAndWait();
        }
    }

    /**
     * Populates the Product info text fields with the data from the users selection.
     * Sets passID to the selected Products ID to be used later so that the ID doesn't change on update.
     * Sets ind to the selected Products index to be used in the updateProduct parameter.
     * Populates each text field with the selected Products data and uses setItems to populate the associatedParts table.
     * @param prod The selected Product to modify.
     */
    public void setSelection(Product prod) {
        oldProduct = prod;
        passID = prod.getId();
        ind = Inventory.getAllProducts().indexOf(prod);

        textfieldModProdID.setText(String.valueOf(oldProduct.getId()));
        textfieldModProdName.setText(oldProduct.getName());
        textfieldModProdInv.setText(String.valueOf(oldProduct.getStock()));
        textfieldModProdPrice.setText(String.valueOf(oldProduct.getPrice()));
        textfieldModProdMax.setText(String.valueOf(oldProduct.getMax()));
        textfieldModProdMin.setText(String.valueOf(oldProduct.getMin()));

        tableModProdAssociatedPart.setItems(oldProduct.getAllAssociatedParts());
    }

    /**
     * Initialize is called with the view loads and populates the tables cell values.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        // initialize values in the available parts table
        tableModProdAvailPart.setItems(Inventory.getAllParts());
        tablecolModProdAvailPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        tablecolModProdAvailPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        tablecolModProdAvailPartInv.setCellValueFactory(new PropertyValueFactory<>("stock"));
        tablecolModProdAvailPartPrice.setCellValueFactory(new PropertyValueFactory<>("price"));

        // initialize values in associated parts table
        tablecolModProdAssocPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        tablecolModProdAssocPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        tablecolModProdAssocPartInv.setCellValueFactory(new PropertyValueFactory<>("stock"));
        tablecolModProdAssocPartPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
    }
}
