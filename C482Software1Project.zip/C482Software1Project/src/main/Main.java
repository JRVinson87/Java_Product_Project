/**
 * The Main class with the main method and data initialization. Javadoc in a separate zip folder named Javadoc.
 * RUNTIME ERROR
 * I had launch(args); before my initialization, so the arrays/tables weren't being populated.
 * moved launch(args); to the bottom of the main method.
 *
 *FUTURE ENHANCEMENT
 * Adding tableviews to track parts and products coming in and out of inventory.
 * This would allow for better part and product availability.
 * You would have better insight on sales as well.
 */

/**
 *
 * @author Joshua Vinson
 */
package main;

import model.InHouse;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.Inventory;
import model.Outsourced;
import model.Product;

public class Main extends Application {

    /**
     * Establishes the root scene and displays first view.
     */
    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("../view/MainMenu.fxml"));
        primaryStage.setScene(new Scene(root, 1000, 400));
        primaryStage.show();
    }

    /**
     * The Main method, launches (init, start) and initializes array values.
     */
    public static void main(String[] args) {

        // Create Part objects
        // Create InHouse
        InHouse handlebars = new InHouse(Inventory.getUniquePartId(), "Handlebars", 19.99, 3, 2, 50, 1);
        InHouse seat = new InHouse(Inventory.getUniquePartId(), "Seat", 29.99, 5, 2, 50, 2);

        //Create Outsourced
        Outsourced grips = new Outsourced(Inventory.getUniquePartId(), "Grips", 9.99, 8, 4, 100, "Grippy");

        // Create Product objects
        Product monster = new Product(Inventory.getUniqueProductId(), "The Monster", 999.99, 5, 1, 10);
        Product bigwheel = new Product(Inventory.getUniqueProductId(), "The Big Wheel", 99.99, 10, 5, 50);

        // Add initial values to observable array lists
        Inventory.addPart(handlebars);
        Inventory.addPart(seat);
        Inventory.addPart(grips);
        Inventory.addProduct(monster);
        Inventory.addProduct(bigwheel);

        // call launch for FXML life cycle
        launch(args);

    }
}
